#include<stdio.h>

int main()
{
    int a[10];
    int i,j,t;
    /* 循环录入数据 */
    printf("input 10 numbers to sort\n");
    for ( i = 0; i < 10; i++)
    {
        scanf("%d",&a[i]);
    }
    /* 起泡法核心循环 */
    printf("\n");
    for ( j = 0; j < 9; j++)
    {
        for ( i = 0; i < 9-j; i++)      //核心思想是行列一次扫描式比较
        {
                if (a[i]>a[i+1])
                {
                   t=a[i];a[i]=a[i+1];a[i+1]=t;
                }                
        }        
    }

    printf("the sorted numbers is\n");
    for ( i = 0; i < 10; i++)
    {
        printf("%d ",a[i]);

    }
    

    return 0;
}