#include<stdio.h>

int main()
{
    int max1(int a,int b,int c,int d);
    int a,b,c,d,max;

    printf("Please enter\n");

    scanf("%d %d %d %d",&a,&b,&c,&d);
    max=max1(a, b, c, d);
    printf("%d",max);
    return 0;
}

int max1(int a,int b,int c,int d)
{
    int max2(int a,int b);
    int max;

    max=max2(a,b);
    max=max2(max,c);
    max=max2(max,d);

    return max;
}

int max2(int a,int b)
{
    if (a>b)
    {
        return a;
    }
    else return b;
}
