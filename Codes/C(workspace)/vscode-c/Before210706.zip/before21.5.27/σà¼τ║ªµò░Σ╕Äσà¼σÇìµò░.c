#include<stdio.h>

int main()
{
    int m=0,n=0;
    int maxroot = 0,minroot = 0;
    printf("enter m,n\n");
    scanf("%d,%d",&m,&n);
    
        //最大公约数计算
    for (int i = 1; i < ((m>n)?n:m); i++)  //判断m，n较大值
    {
        if (m%i==0&&n%i==0)
        {
            maxroot=i;
        }
    }
    //最小公倍数
    for (int k = (m>n)?m:n; ; k++)
    {   minroot=k;
        if (k%m==0&&k%n==0)
            break;
        
    }

    printf("%d,%d\n",maxroot,minroot);

    return 0;
}
