#include<stdio.h>
int main()
{
    int a[3][4]={{1,2,3,4},{9,8,7,6},{-10,10,5,2}};
    int i,j,x,y;
    int z=a[0][0];

    for ( i = 0; i < 3; i++)
    {
        for ( j = 0; j < 4; j++)
        {
            if (a[i][j]>z)
            {
                z=a[i][j];
                x=i;
                y=j;
            }
            
        }
        
    }
    printf("the maxium is %d\nlocated in row %d,collum %d",z,x+1,y+1);
    
    

    return 0;
}