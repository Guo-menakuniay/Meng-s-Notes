#include <stdio.h>
int main()
{
    int year,leap;
    printf("Please enter the year you wanna to check\n");
    scanf("%d",&year);

    if(year%4==0)
      {
          if(year%100!=0)
            leap=1;
          else leap=0;
          if (year%400==0)
          {
              leap=1;
          }
            
      }
    else leap=0;
    
    
    /* if( (year%4==0&&year%100!=0)||(year%4==0))
         leap=1;
       else                                         该程序依然可用
         leap=0;  */  
    
    if (leap==0)
       printf("这一年不是闰年\n");      /* leap year代表闰年 */

    else
       printf("这一年是闰年\n");
   
    return 0;
}