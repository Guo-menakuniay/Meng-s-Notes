#include <stdio.h>

int main()
{
   char a,b,c,d,e,a1,b1,c1,d1,e1;
   scanf("%c%c%c%c%c",&a,&b,&c,&d,&e);
   a1=a+4;
   b1=b+4;
   c1=c+4;
   d1=d+4;
   e1=e+4;

   printf("%c%c%c%c%c",a1,b1,c1,d1,e1);
   return 0;
}