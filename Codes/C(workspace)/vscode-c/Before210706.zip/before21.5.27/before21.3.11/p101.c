#include <stdio.h>
int main()
{
    char grad;
    printf("Please enter your rank\n");
    scanf("%c",&grad);

    printf("Your score:");
    switch (grad)
    {
    case'A':printf("80-90\n");break;
    case'B':printf("70-80\n");break;
    case'C':printf("60-70\n");break;
    case'D':printf("50-60\n");break;
    
    default:printf("enter data error\n");
        break;
    }


    return 0;
}