#include <stdio.h>
#include <math.h>
int main()
{
    float r,h;
    scanf("%f",&r);
    const double pi=acos(-1);
    printf("%f",pi);
    printf("圆周长为%f\n",2*pi*r);
    printf("圆面积为%f\n",pi*r*r);
    printf("圆球的表面积为%f\n",4*pi*r*r);




    return 0;
}