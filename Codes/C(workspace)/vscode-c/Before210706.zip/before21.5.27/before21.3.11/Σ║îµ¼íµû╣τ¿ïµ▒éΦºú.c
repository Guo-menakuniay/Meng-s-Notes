#include<stdio.h>
#include<math.h>

double a,b,c,delta,disc,x1,x2,x1comp,x2comp;
int m;
int main()
{  
    

    printf("Please enter a,b,c following this format\n");
    scanf("%lf,%lf,%lf",&a,&b,&c);
    printf("Please enter the precise you want after the point\n");
    scanf("%d",&m);

    delta=b*b-4*a*c;

    if(delta>=0)
        {
            disc=sqrt(delta);
            x1=(-b+disc)/2*a;
            x2=(-b-disc)/2*a;
            printf("The solution of this equation is\n");
            printf("x1=%.*f \nx2=%.*f\n",m,x1,m,x2);
        }
    else
    {
        disc=sqrt(-delta);
        x1=-b/2*a;
        x2=-b/2*a;
        x1comp=disc/2*a;
        x2comp=-disc/2*a;
        printf("The solution of this equation is\n");
        printf("x1=%.*f+%.*fi \nx2=%.*f+%.*fi",m,x1,m,x1comp,m,x2,m,x2comp);
    }

    
    return 0;
}
