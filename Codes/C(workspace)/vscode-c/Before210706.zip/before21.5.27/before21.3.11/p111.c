#include<stdio.h>

int main()
{
    int x=0,sum;
    
    while (x<=100)
    {
        sum=0;
        sum=sum+x;

        x++;
    }
    printf("%d",sum);
    

    return 0;
}