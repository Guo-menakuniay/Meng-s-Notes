#include <stdio.h>
int main()
{
    int age;
    int years=1;
    printf("enter\n");
    scanf("%d",&age);
    printf("%d,%d,%d",age,years,age+years);
    return 0;
}