#include <stdio.h>
  
/*定义两个全局变量*/
int x=1;
int y=2;
int mid();
int main(void)
{
    int result;
    result = mid();
    printf("result 为: %d\n",result);
    return 0;
}
extern int x ;
extern int y ;
int mid()
{
    return x+y;
}