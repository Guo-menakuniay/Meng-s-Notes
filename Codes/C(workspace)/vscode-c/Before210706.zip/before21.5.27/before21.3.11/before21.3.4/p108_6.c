#include<stdio.h>

int main()
{
    float x,y;
    printf("Please enter the value of x\n");
    scanf("%f",&x);

    if (x<10)
    {
        if (x<1)
        {
            y=x;
        }
        else
            y=2*x-1;
    }
    else 
        y=3*x-11;

    printf("The value of y is %f\n",y);

    return 0;
}