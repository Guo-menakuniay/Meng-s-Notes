#include<stdio.h>
#include<math.h>
int main()
{
    long double pi=acos(-1);
    printf("*****\n");
    printf(" *****\n  *****\n");
    printf("    *****\n");
    printf("%8.4lf",pi+100000000);
    return 0;
}