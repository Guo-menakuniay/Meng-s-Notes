#include <stdio.h>

int main()
{
   int max(int a ,int b ,int c);
   int x,y,z;
   int m;
   printf("Please enter the numbers you want to compre\n");
   scanf("%d,%d,%d",&x,&y,&z);
   m=max(x,y,z);
   printf("The biggest one is %d\n",m);

   return 0;

}

int max(int a ,int b ,int c)
{
    int m,k;
    if(a>b) m=a;
    else m=b;

    if(m>c) k=m;
    else k=c;    

    return k;
}