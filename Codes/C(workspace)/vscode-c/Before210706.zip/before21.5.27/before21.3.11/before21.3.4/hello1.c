#include<stdio.h>

int main()
{   printf("Hello World! LXDog\n");

    return 0;
}