#pragma warning(disable:4996)
#include <stdio.h>
int max(int x,int y);
int main()
{
    int a,b,c;
    scanf("%d,%d",&a,&b);
    c=max(a,b);
    printf("The bigger one is %d\n",c);
    return 0;
}

int max(int x,int y)
{
    int z;
    if(x>y)z=x;
    else z=y;
    return z;
}