#include <stdio.h>

#include <stdlib.h>

#include <string.h>

struct node

{

    char l;

    struct node *next;

};

int main()

{

    struct node *p, *head, *q;

    int k = 0, let[127] = {0}, m, i = 1, j = 0, v = 0;

    char s[100] = {0}, key[95] = {0}, in[95] = {0}, out[95] = {0}, c;

    gets(s);

    k = strlen(s);

    FILE *a;

    FILE *b;

    a = fopen("in.txt", "r");

    b = fopen("in_crpyt.txt", "w");

    for (i = 0; i < k; i++)

    {

        if (let[s[i]] == 0)

            let[s[i]]++;

        else

            s[i] = 0;

    }

    for (i = 0; i < k; i++)

    {

        if (s[i] != 0)

        {

            key[v] = s[i];

            v++;

        }

    }

    for (i = 32; i < 127; i++)

    {

        if (let[i] == 0)

        {

            key[v++] = i;

        }

    }

    puts(key);

    head = p = (struct node *)malloc(sizeof(struct node));

    head->l = key[0];

    for (int i = 1; i < 95; i++)

    {

        p->next = (struct node *)malloc(sizeof(struct node));

        p = p->next;

        p->l = key[i];

    }

    p->next = head;

    q = p;

    p = head;

    m = p->l;

    in[0] = m;

    out[94] = m;

    q->next = p->next;

    free(p);

    p = q->next;

    i = 1;

    j = 0;

    while (p != p->next)

    {

        if (i != m)

        {

            q = p;

            p = p->next;

            i++;

        }

        else

        {

            out[j] = p->l;

            j++;

            in[j] = p->l;

            m = p->l;

            q->next = p->next;

            free(p);

            p = q->next;

            i = 1;

        }

    }

    out[93] = p->l;

    in[94] = p->l;

    c = fgetc(a);

    while (c != EOF)

    {

        for (i = 0; i < 95; i++)

            if (c == in[i])

            {

                fprintf(b, "%c", out[i]);

                break;

            }

        if (i == 95)

            fprintf(b, "%c", c);

        c = fgetc(a);

    }

    fclose(a);

    fclose(b);

}
