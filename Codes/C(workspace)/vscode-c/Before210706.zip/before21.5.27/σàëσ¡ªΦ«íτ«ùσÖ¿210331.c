#include<stdio.h>
#include<math.h>

int main()
{
    double o1,o2,n0 =1,n1,r1,r2,l,l1;
    double s11,s12,s21,s22;
    double lf0,lf1;
    printf("Please enter the values as the order n1,r1,r2,l\n" );
    scanf("%lf,%lf,%lf,%lf",&n1,&r1,&r2,&l);

    /* 透镜的光焦度计算 */
    o1=(n1-n0)/r1;
    o2=(n1-n0)/r2;

    /* 系统矩阵的各项值 */
    s11=1-(o2*l/n1);
    s12=o1+o2-o2*l/n1;
    s21=-l/n1;
    s22=1-o1*l/n1;

   /* 计算顶焦距 */
    lf0=(n0*s11)/s12;
    lf1=(n0*s22)/s12;

    /* 当像距处在焦点上时 */
    l1=lf1;
    l=(s11*l1-s21)/(s12*l1-s22);

    printf("从左到右的光焦度:\n %lf,%lf\n",o1,o2);
    printf("matrix:\n");
    printf("%lf   %lf\n%lf   %lf\n\n",s11,s12,s21,s22);
    printf("l=%lf, lf1=%lf\n",l,lf1);
    printf("o1=%lf, o2=%lf\n",o1,o2);
    
    int i=0;
    double beta;
    printf("\ndo you need further calculate,1 for yes,0 for no\n");
    scanf("%d",&i);
    if (i==1) {
        printf("please enter the beta and caculate the l\n");
        scanf("%lf",&beta);
        
        l=n0*(s11-1/beta)/s12;
        l1=(s21-l*s22)/(s11-l*s12);
        
        printf("l=%lf\tl1=%lf",l,l1);
        
    }
    return 0;
}
