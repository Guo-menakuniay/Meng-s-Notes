#include<stdio.h>
int main()
{
    //试验数组 可更改
    int a[15]={1,2,-3,-4,-5,-6,-7,8,9,0,11,12,13,-14,15};
    int m,k,sum=0;
    
    printf("请输入从第几位数开始循环\n");
    scanf("%d",&k);
    m=k-1;
  
    for (int i = 0; i <10;i++)
    {
        //题目所给的条件限制
     if (m>14){
        m=m-15;}
     if (a[m]==0){
        break;}
     if (a[m]>0){
        sum=sum+a[m];}
    m++;
        
    }
    
    printf("按题意所得结果为%d",sum);
    return 0;
}

