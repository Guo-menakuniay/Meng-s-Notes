#include <math.h>
#include <stdio.h>

double f(double x)             /* 定义函数及导函数 */
{return x*x*x*x*x-x*x*x*x+4*x*x-6*x+1; }

double f1(double x)           
{return 5*x*x*x*x-4*x*x*x+8*x-6; }

int main()
{
    double x=-1.5;   /* 令一个与根在同一单调区间的初始值 */

    while(fabs(f(x))>=1e-5)
    {
        x=x-f(x)/f1(x);
    }
    
    printf("该函数在-3到0的根为：%lf",x);
    return 0;
}
