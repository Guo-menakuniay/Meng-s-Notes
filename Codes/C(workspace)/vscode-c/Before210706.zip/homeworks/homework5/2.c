/* 弦截法 */
#include<stdio.h>
#include<math.h>
double func(double x);
double point(double a,double b);
/* 定义函数 */
double func(double x)
{
   return x*x*x*x*x-x*x*x*x+4*x*x-6*x+1;
}
/* 求解两点连线与x轴交点的坐标 */
double point(double a,double b)   /*  此处有func(a)>0;func(b)<0 */
{
    double x;
     x=b+((a-b)*func(b))/(func(b)-func(a));

    return x;
}

int main()
{
    double x;
    double a=-3,b=0;
    x=point(a,b);

    while (func(x)>=1e-5)
    {
        if (func(x)<0)
        {
            a=x;b=b;x=point(a, b);
        }
        if (func(x)>0)
        {
            a=a;b=x;x=point(a, b);
        }
    }
    /*输出小数点后5位*/
    printf("%.5lf",x);

    return 0;
}
