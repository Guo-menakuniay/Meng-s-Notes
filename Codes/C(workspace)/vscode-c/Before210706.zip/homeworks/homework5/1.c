/* 牛顿迭代法 */
#include<stdio.h>
#include<math.h>
double func(double x);
double ffunc(double x);

double func(double x)
{
   return x*x*x*x*x-x*x*x*x+4*x*x-6*x+1;
}

double ffunc(double x)
{
    return 5*x*x*x*x-4*x*x*x+8*x-6;
}

int main()
{
    double a=-1.5;
    while ( fabs(func(a))>=1e-6 )
    {
        a=a-(func(a)/ffunc(a));
    }
    
    printf("该方程的解是:\n");
    printf("  %.5lf\n",a);

    return 0;
}