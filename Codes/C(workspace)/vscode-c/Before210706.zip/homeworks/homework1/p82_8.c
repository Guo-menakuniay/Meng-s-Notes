#include<stdio.h>

int main()
{
    printf("1.字符型\n2.使用printf函数以%%d形式输出\n3.并非任何情况下都能代替；并不是无条件等价\n");

    /* 
    直接查看答案
         1.字符型
         2.使用printf函数以%d形式输出
         3.并非任何情况下都能代替；并不是无条件等价
    */

    return 0;
}