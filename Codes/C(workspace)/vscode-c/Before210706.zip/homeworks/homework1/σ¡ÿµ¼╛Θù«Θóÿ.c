#include<stdio.h>
#include<math.h>

int main()
{
    float rate1=0.015,rate2=0.021,rate3=0.0275,rate5=0.03,rate0=0.0035,money0=1000,money1,P;
    int m;

    printf("请选择你的存款方案\n");
    printf("1.一次存五年\n2.先存2年，到期后本息再存3年\n3.先存三年，到期后本息再存两年\n4.存一年，连续操作五次\n5.活期存款\n");
    scanf("%d",&m);

    
    /* 五年期存款 */
    if (m==1)
    {
        P=money0*(1+5*rate5);
    }
    
    /* 方案二 */
    if (m==2)
    {
        float middle;
        middle=money0*(1+2*rate2);
        P=middle*(1+5*rate5);
    }

   /*  方案三  */ 
    if (m==3)
    {
        float middle;
        middle=money0*(1+3*rate3);
        P=middle*(1+2*rate2);
    }
    
    /* 方案四 */
    if (m==4)
    {
        float middle;
        int i=1;
        P=money0;
        while (i<=5)
        {
            P=P*(1+rate1);
            i++;
        }    
    }
    /* 方案五 */
    if(m==5)
    {
        int i=1;
        P=money0;

        while (i<=4*5)
        {
            P=P*(1+rate0/4);
            i++;
        }
        
    }
    
    printf("你最后获得的金额是%8.2f\n",P);

    return 0;
}