#include<stdio.h>
#include<math.h>
#define PI 3.1415926

int main()
{
    float r=1.5,h=3,l,s,ball_s,ball_v,collum_v;

    l=2*PI*r;
    s=PI*r*r;
    ball_s=4*PI*r*r;
    ball_v=4*PI*r*r*r/3;
    collum_v=s*h;

    printf("圆周长为%f\n圆面积为%f\n圆球表面积%f\n圆球体积%f\n圆柱体积%f\n",l,s,ball_s,ball_v,collum_v);


    return 0;
}