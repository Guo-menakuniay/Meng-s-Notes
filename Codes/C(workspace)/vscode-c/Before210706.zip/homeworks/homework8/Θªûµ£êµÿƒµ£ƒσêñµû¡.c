#include<stdio.h>
int leapyear(int year);
int main()
{
    int year0,week0,day=0;
    int a[12]={0};
    int b[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    int leap; //闰年判断因子

    printf("请输入年份和当年第一天的星期数（用0代表周日，1代表周一，以此类推），示例：2020年3\n");
    scanf("%d年%d",&year0,&week0);

    /* 闰年判断 */
    leap=leapyear(year0);   //leap=0 不是闰年，leap=1 是闰年
    if (leap==1)
    {
        b[1]=b[1]+1;
    }
    printf("该年每月的第一天的信息：\n");
    //星期判断与输出
    for (int i = 0; i <=11; i++)
    {
        day=day+b[i-1];
        a[i]=day%7+week0;
        if (a[i]>=7)
        {
            a[i]=a[i]-7;
        }
        printf("%d年%d月1日是星期",year0,i+1);
        
        switch (a[i])
        {
        case 0:printf("日\n");break;
        case 1:printf("一\n");break;
        case 2:printf("二\n");break;
        case 3:printf("三\n");break;
        case 4:printf("四\n");break;
        case 5:printf("五\n");break;
        case 6:printf("六\n");break;
        
        default:
            break;
        }
    }
    
    return 0;
}

int leapyear(int year)     //闰年判断函数
{
    int leap;

    if(year%4==0)
      {
          if(year%100!=0)
            leap=1;
          else leap=0;
          if (year%400==0)
          {
              leap=1;
          }
            
      }
    else leap=0;
    
    return leap;
}