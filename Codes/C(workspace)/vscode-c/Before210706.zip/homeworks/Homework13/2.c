#include<stdio.h>
#include<string.h>
struct athlete
{	long ID;   			// ID为运动员编号
	char name[20];    	// name为运动员姓名
	int count;			// count为统计选票的得票次数
 	float mark;       	// mark统计给运动员打的分（0~100分）
};


int main()
{
    struct athlete file[100];
    void addathlete(struct athlete *person,int n); //添加运动信息，n为人数
    void addcount(struct athlete *person,int n); 
    void swap(struct athlete *person,int length);
    void output(struct athlete *person,int length);

    //添加运动员信息及成绩
    addathlete(file,10);
    addcount(file,10);
    //成绩排序
    swap(file,10);
    //打印成绩
    output(file,10);


    return 0;
}
void addathlete(struct athlete *person,int n)
{
    for (int i = 0; i < n; i++)
    {
        scanf("%f %s",&person[i].ID,person[i].name);
    }
    
}
void addcount(struct athlete *person,int n)
{
    for (int i = 0; i < n; i++)
    {
        scanf("%d %f",&person[i].count,&person[i].mark);
    }
    
}
void swap(struct athlete *person,int length)
{
    struct athlete temp;
    for (int j; j < length; j++)
    {
        for (int i = 0; i < length; i++)
        {
            if (person[i].count<person[i+1].ID)
                {
                    temp=person[i];
                    person[i]=person[i+1];
                    person[i+1]=temp;
                }
        }
    }
}
void output(struct athlete *person,int length)
{
    for (int i = 0; i < length; i++)
    {
        printf("NO.%d ",i+1);
        printf("%f %s %d %f",person[i].ID,person[i].name,person[i].count,person[i].mark);
    }
    
}