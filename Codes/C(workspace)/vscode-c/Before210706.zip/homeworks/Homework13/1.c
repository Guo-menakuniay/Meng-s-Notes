#include<stdio.h>
#include <string.h>
struct goods
{
    long ID;
    char name[20];
    char factory[40];
    float price;
    int sum;  //商品数量
};

int main()
{
    struct goods tag[100];
    void intputGoods(struct goods *pGoods,int n);
    void outputGoods(struct goods *pGoods,int n);
    void searchGoods(struct goods *pGoods, char *name);
    printf("请录入商品信息\n");
    //数据的输入与输出
    for (int i=0; i<10; i++) {
        intputGoods(tag, i);
    }
    for (int i=0; i<10; i++) {
        outputGoods(tag, i);
    }
    //商品查找
    char find[20];
    printf("请输入要查找的商品名称\n");
    scanf("%s",find);
    searchGoods(tag,find);
    
    return 0;
}
void intputGoods(struct goods *pGoods,int n)
{
        scanf("%ld %s %s %f %d",&pGoods[n].ID,
                               pGoods[n].name,
                               pGoods[n].factory,
                               &pGoods[n].price,
                               &pGoods[n].sum      );
}

void outputGoods(struct goods *pGoods,int n)
{
        printf("%ld %s %s %f %d\n",pGoods[n].ID,
                                 pGoods[n].name,
                                 pGoods[n].factory,
                                 pGoods[n].price,
                                 pGoods[n].sum      );
    }

void searchGoods(struct goods *pGoods, char *name)
{
    for (int i=0; i < 10; i++)
    {
        if (strcmp(name, pGoods[i].name)==0)
        {
            printf("找到了该商品\n");
            outputGoods(pGoods, i);
        }
    }
}
