#include<stdio.h>
#include<math.h>

int main()
{
    int a,i=0;
    int x[8];

    printf("请输入一个小于255的正整数，以转换为十进制\n");
    scanf("%d",&a);

    if (a>0&&a<=255)
    {
        while (a!=0)
        {
            x[i]=a%2==1;
            a=(a-x[i])/2;
            i++;
           
        }
        
    printf("该数的二进制为：\n");
    
        for (int n=7;n>=0;n--)
    {
        printf("%d\t",x[n]);
    }
    
        

    }
    else printf("输入数字不合规范，请重新检查。\n");

    return 0;
}
