#include <stdio.h>

/* 素数判断部分 */
int sec(m)
{
    int a=0;  // 素数的个数
    int i=0;
    int num=m;
    for(int i=2;i<num;i++)
    {
        if(num%i==0)  {a++;}
    }

    if(a==0)  {i=1;}
    else  { i=0; }

    return i;
}

int main()
{
    int x,n=0;

    printf("请输入一个整数（2<x<2000)\n");
    scanf("%d",&x);
    if (x>=2&&x<=2000)
    {
        for (int m = 2; m <= x; m++)
        {
            if (sec(m)==1)
            {
                printf("%d\t",m); n++;
                while(n%8==0) {  printf("\n");break;}
            }
            
            
        }
        
    }
    

    return 0;
}
