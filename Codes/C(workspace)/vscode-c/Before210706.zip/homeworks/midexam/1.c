#include<stdio.h>
#include<stdlib.h>   //调用 rand（）生成假随机数
#include<time.h>     //调用系统时间

int main()
{
    srand((unsigned)time(NULL));  //利用系统时间的假随机性对 rand（）函数的种子进行重新播种，保证每次的随机数不同
    int get,i;
    int number = rand() % 100+1;  //生成0-100的随机数
    
    printf("按下回车开始游戏。输入数据以获得“过大”“过小”“相等”的提示。\n");
    getchar();

    
    printf("输入一个0到100的数字以开始。\n");
    for  (i = 1; ; i++)    //大小判断
    {
        scanf("%d",&get);
        if (get>number)
        {
            printf("Too big\n");
        }
        if (get<number)
        {
            printf("Too small\n");
        }
        if (get==number)    //条件成立 跳出循环
           break;
    }
    
    printf("恭喜你猜中了答案%d,共用%d次\n",number,i);

    return 0;
}
