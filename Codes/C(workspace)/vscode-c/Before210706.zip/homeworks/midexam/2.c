#include<stdio.h>
int main()
{
    int number,middle,i=2,m /* 数组计数因子 */,k = 0;
    int a[10];
    for(number=2;number<=100;number++) //2-100一次运行
    {   m=0;
        int count=0;
        middle=number;        //中间量
        while (middle!=1)
        {   //因数的计算与循环
            if (middle%i==0)
              {
                  a[m]=i;
                  m++;
                  middle=(middle/i);    //中间量的步进
                  i=2;  count++;
                  continue;
              }
            i++;
        }
       if (count==1)
       {
           printf("%d为质数  ",number);
       }
       else
       {
       //结果打印（至倒数第二位）
       printf("%d=",number);
       for (; a[k+1]!=0 ; k++)
       {
           printf("%d*",a[k]);
       }
       //最后一个因数的打印并换行
        printf("%d  ",a[k]);
       }

        //单词循环中相关量的清零
        k=0;
        for (int clear=0; clear<=10; clear++) {
            a[clear]=0;
        } 
     }

    return 0;
}
