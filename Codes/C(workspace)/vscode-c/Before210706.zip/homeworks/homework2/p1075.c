#include<stdio.h>
#include<math.h>

int main()
{
    int number,a;
    float s;

    printf("please enter a positive number within 0 to 100\n");
    scanf("%d",&number);

    if (0<=number&&number<=1000)
    {
        s=sqrt(number);
        a=(int)s;
        printf("the integer part of the squre of this number is %d\n",a);
    }
    else
        {
            printf("there is something wrong with the input, please make sure you have followed the rules and try agin");
        }
    return 0;
}