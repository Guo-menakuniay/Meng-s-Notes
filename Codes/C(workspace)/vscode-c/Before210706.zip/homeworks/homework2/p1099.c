#include<stdio.h>

int main()
{
    int number,i = 0;
    int p1=0,p2=0,p3=0,p4=0,p5=0;
    float a=0,b=0,c=0,d=0;

    printf("please enter a number(<=100000)\n");
    scanf("%d",&number);

    /* 五位数的情况 */
    if (number-9999>0)
    {
        i=5;
        a=number/10000;
        p1=(int)a;
        b=(number-p1*10000)/1000;
        p2=(int)b;
        c=(number-p1*10000-p2*1000)/100;
        p3=(int)c;
        d=(number-p1*10000-p2*1000-p3*100)/10;
        p4=(int)d;
        p5=number-p1*10000-p2*1000-p3*100-p4*10;
    }
    
    /* 四位数情况 */
    if (number-9999<=0&&number-999>0)
    {
        i=4;
        a=number/1000;
        p1=(int)a;
        b=(number-p1*1000)/100;
        p2=(int)b;
        c=(number-p1*1000-p2*100)/10;
        p3=(int)c;
        p4=number-p1*1000-p2*100-p3*10;
    }
    
    /* 三位数情况 */
    if (number-999<=0&&number-99>0)
    {
        i=3;
        a=number/100;
        p1=(int)a;
        b=(number-p1*100)/10;
        p2=(int)b;
        p3=number-p1*100-p2*10;
    }
    
   /*  两位数情况 */
    if (number-99<=0&&number-9>0)
    {
        i=2;
        a=number/10;
        p1=(int)a;
        p2=number-p1*10;

    }

    /* 一位数情况 */
    if(number-9<=0)
    {
        i=1;
        p1=number;
    }

    
    int q[5];
    q[0]=p1; q[1]=p2; q[2]=p3; q[3]=p4; q[4]=p5;
    int m=0;
    printf("该数字的位数为%d\n",i);
    printf("数字的正序依次是：\n");
    
    for (int m=0; m<5; m++)
    {
        printf("%d ",q[m]);
        if (m>=i-1) break;
        
    }
   
    
    printf("\n数字的倒序排列是：\n");
    
    for (m=i-1; m>=0; m--)
    {
        printf("%d ",q[m]);

    }
    
     return 0;
}
