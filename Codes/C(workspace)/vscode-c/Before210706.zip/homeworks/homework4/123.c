#include <stdio.h>
#include <math.h>
int main()
{
   double PI,s;//由于输出要求为精度15，所以需要定义为双精度型
   int i,n;
   PI=0;
   printf("请输入一个大于0小于等于100的整数：");
   scanf("%d",&i);                 //从键盘获取i值
   for(n=1;n<=2*i+1;n=n+2)
   {s=pow(-1,(n-1)/2);             //由于估计PI的式子是正负相间的，所以需要此式来加入正负号
       PI=PI+4*s/n;
   }
   printf("PI=%.15f\n",PI);        //精度为15输出最终值
   return 0;
}
