#include <stdio.h>
int a=2;

int perfect(int a)
{
    int n = 1,sum = 0;
    int k;
    while (n<a)
    {
        for(;a%n==0;n++)
        {
            sum=sum+n;
        }
        n++;
    }
    if (sum==a)
    {
        k=a;
    }
    else k=0;

    return k;
}

int main()
{
    int final=0;

    printf("1000以内的完数及其求和为\n");
    printf("1");
    
    while (a<=1000)
    {
        if (perfect(a)!=0)
        {
            printf("+");
            printf("%d",perfect(a));
            final=final+perfect(a);
        }
        a++;
    }
        printf("=%d\n",final);

        return 0;
    }
    
