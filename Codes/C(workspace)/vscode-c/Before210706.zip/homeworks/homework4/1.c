#include<stdio.h>
#include<math.h>

int main()
{
    double pi=0.0,n=1.0,term=1;
    int sign=1,i=1;
    int m;

    printf("please enter the input i(0<i<=100000\n");
    scanf("%d",&m);

    while (n<=2*m+1)
    {
        pi=pi+term;
        n=n+2;
        sign=-sign;
        term=sign/n;
    }
    
    pi=pi*4;
    printf("pi=%.15f\n",pi);

    return 0;
}
