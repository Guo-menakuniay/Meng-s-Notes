#include <stdio.h>
#include <math.h>

int GetFactorSum(int n)
{
    int i, sum = 0;
    for (i = 1; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            if (i == 1 || i * i == n)
                sum += i;
            else
                sum += i + n / i;
        }
    }
    return sum;
}

int main()
{
    int i, num;
    printf("100000以内的亲密数有：\n");
    for (i = 2; i <= 100000; i++)
    {
        num = GetFactorSum(i);
        if (GetFactorSum(num) == i && i <= num)
            printf("%d %d\n", i, num);
    }
    return 0;
}
