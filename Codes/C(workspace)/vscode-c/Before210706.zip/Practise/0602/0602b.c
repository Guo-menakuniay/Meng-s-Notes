#include<stdio.h>

int main()
{
    int maxroot(int a,int b);
    int min(int a,int b);
    int a=0,b=0;
    printf("请输入两个整数\n");
    scanf("%d %d",&a,&b);
    printf("他们的最大公约数与最小公倍数为： %d,%d\n",maxroot(a,b),min(a,b));
    
    printf("请输入你要化简的分数如a/b \n");
    scanf("%d/%d",&a,&b);
    printf("化简结果为： %d/%d",a/maxroot(a,b),b/maxroot(a,b));

    return 0;
}


int maxroot(int m,int n)
{   int maxroot=0; 
    //最大公约数计算
    for (int i = 1; i < ((m>n)?n:m); i++)  //判断m，n较大值
    {
        if (m%i==0&&n%i==0)
        {
            maxroot=i;
        }
    }
    return maxroot;
}

int min(int m,int n)
{
    int minroot=0;
    //最小公倍数
    for (int k = (m>n)?m:n; ; k++)
    {   minroot=k;
        if (k%m==0&&k%n==0)
            break;
        
    }
    return minroot;
}