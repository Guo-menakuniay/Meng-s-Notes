#include<stdio.h>
#include<math.h>
int  main()
{
    float squre(int a,int b,int c);
    void juge(int a,int b,int c);
    int a,b,c;

    printf("请从小到大输入三角形的三边\n");
    scanf("%d %d %d",&a,&b,&c);
    
    juge(a,b,c);
    return 0;
}
float squre(int a,int b,int c)
{
    float s;
    float p;
    p=(float) (a+b+c)/2;
    s=sqrt(p*(p-a)*(p-b)*(p-c));
    return s;
}
void juge(int a,int b,int c)
{
    if (a+b<c)
    {
        printf("error\n");
    }
    else
    {
    if (a*a+b*b>c*c)
    {
        printf("钝角三角形 面积为%f",squre(a,b,c));
    }
    if (a*a+b*b<c*c)
    {
        printf("钝角三角形 面积为%f",squre(a,b,c));
    }
    if (a*a+b*b==c*c)
    {
        printf("直角三角形 面积为%f",squre(a,b,c));
    }
    }    
}