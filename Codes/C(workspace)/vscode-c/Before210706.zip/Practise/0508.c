#include<stdio.h>
#include<time.h>
#include<stdlib.h>
int main()
{
    int a[30],b[30];
    int mid;
    srand((unsigned) time(NULL));
    //随机生成a数组
    for(int i = 0; i <= 19; i++)
    {
        a[i] = rand()%1000+1;
    }
    //a数组排序
    for(int j = 0; j <= 19; j++)
    {
        for(int i = 0; i <= 19; i++)
        {
            if(a[i] > a[i + 1])
            {
                mid = a[i + 1];
                a[i + 1] = a[i];
                a[i] = mid;
            }
        }
    }
    //复制a[]数组至b[]
    for (int i=0; i<=19; i++)
    {
        b[i]=a[i];
    }

    //插入中间数
    int k, place = 0;
    printf("Please input a number\n");
    scanf("%d", &k);

    for(int i = 0; i <= 19; i++)
    {
        if(k >= a[i]&&k <= a[i + 1])
        { place = i + 1; break;}
    }
    //may problem in a[19]
    if(k>a[19]){place=20; }

    for(int i=place;i<=19;i++)
    {
        a[i+1]=b[i];
    }
    //insert the input value
    a[place]=k;

    printf("Please enter a number to ensure whether it on the list or not\n");
    int get,position=0;
    scanf("%d",&get);

    for(int i=0;i<=20;i++)
    {

        if(get==a[i])
        {

            position=i;
            break;
        }
        else {position=55;}
    }

    //output
    if(position==55){printf("Not at this list.\n");}
    if(position!=55){printf("At this list,in the position of %d\n",position+1);}

     for(int m=0;m<=20;m++)
    {
        printf("%d ",a[m]);
    }

    return 0;
}