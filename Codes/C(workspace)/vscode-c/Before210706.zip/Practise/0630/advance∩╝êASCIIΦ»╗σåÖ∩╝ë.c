#include<stdio.h>
struct Patient
{
    int ID;
    int times;
    int readings[20];
};

int main()
{
    void writein(struct Patient* p,FILE *fp,int *n);
    void readout(FILE *fp,int *n);
    struct Patient list[100];
    int n; /*定义所收集的患者数量*/  int* pn=&n;
    FILE *fp; char filename[100];
    printf("please enter the name of file:\n");
    scanf("%s",filename);
    fp=fopen(filename,"w+");  //新建文件
    writein(list,fp,pn);  //写入文件
    rewind(fp);  //重置文件指针
    readout(fp, pn);
    
    return 0;
}
void writein(struct Patient* p,FILE *fp,int *n)
{
    int id=0,times = 0,readings[10]; //上限10次有效读数
    printf("开始录入数据\n");
    //录入ID部分
    for (int j=0;; j++)
    {
        printf("请输入病人ID(输入-1结束）:\n");
        scanf("%d",&id);
        if (id==-1) {*n=j; break;}
        fprintf(fp,"%d\t",id);
        //录入测量值部分
        printf("输入测量值(以0结束):\n");
        for (int i = 0; ; i++)
        {
            int temp=0;
            scanf("%d",&temp);
            if (temp!=0)
            {
                readings[i]=temp;
            }
            else
            {
                times=i;
                break;
            }
        }
        //写入测量数据
        fprintf(fp,"%d\t",times); //写入times
        for (int i = 0; i < times; i++)
        {
            fprintf(fp,"%d ", readings[i]);
        }
    }
}
void readout(FILE *fp,int *n)
{
    void print(FILE *fp,int *n);
    printf("----The out put------\n");
    printf("Patient ID\tBP avgerage\n");
    printf("---------------------------\n");
    print(fp,n);
}
void print(FILE *fp,int *n)
{
    for (int i = 0; i < *n; i++)
    {
        int id,times;
        int avg,sum=0;
        fscanf(fp,"%d%d",&id,&times); //读取ID和times
        for (int i = 0; i < times; i++)
        {
            int temp=0;
            fscanf(fp,"%d",&temp);
            sum=sum+temp;
        }
        avg=sum/times;
        //打印部分
        printf("\t%d\t%d\n",id,avg);
    }
    printf("totally there are %d patients",*n);
}
