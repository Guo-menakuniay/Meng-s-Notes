#include<stdio.h>
struct Patient
{
    int ID;
    int times;
    int readings[20];
    int BPaverge;
};

int main()
{
    void input(struct Patient* list,int* n);                        //读取结构体数组 pnum为病人数量的指针
    void fileinput(struct Patient* list,FILE *fp,int n);            //写入文件
    void fileoutput(struct Patient* list,FILE *fp,int n);            //取出文件
    void print(struct Patient* list,int num);
    struct Patient list[100];
    //struct Patient *p = list;  //定义结构体数组的指针
    int num; int* pnum=&num; //病人个数
    printf("请输入患者的ID和测量的结果\n");
    input(list,pnum); //运行读取函数
    //文件操作部分
    FILE *fp;
    fp=fopen("/Users/menakuniay/Documents/Codes/C\(workspace\)/vscode-c/Practise/0630/list.txt","w+");
    fileinput(list,fp,num);  //将数据写入文件
    struct Patient output[100];  //新定义一个数组实践从文件中读取数据
    rewind(fp);
    fileoutput(output,fp,num);  //从文件中读取数据
    fclose(fp); //关闭文件
    print(output, num);

    return 0;
}

void input(struct Patient* list,int* n)
{
    int avg(int a[],int n);
    for(int i=0;i<10000;i++)
    {
        //ID
        printf("输入患者的ID(以-1截止):\n");
        scanf("%d",&list[i].ID);
        if(list[i].ID==-1)
        {*n=i; break;}
        printf("输入每次的测量结果(以0截止):\n");
        for(int j=0;j<1000;j++)
        {
            int temp;
            scanf("%d",&temp);
            if(temp==0)
            {
                list[i].times=j;
                break;
            }
            else list[i].readings[j]=temp;
        }
        list[i].BPaverge=avg(list[i].readings,list[i].times);
    }
}
void fileinput(struct Patient* list,FILE *fp,int n) //文件写入 写进结构体数组的前n项
{
    for (int i = 0; i < n; i++)
    {
        fwrite(&list[i],sizeof(struct Patient),1,fp);
    }
}
void fileoutput(struct Patient* list,FILE *fp,int n)  //从文件中读取 读取n项至结构体数组
{
    for (int i = 0; i < n; i++)
    {
        fread(&list[i],sizeof(struct Patient),1,fp);
    }
}
int avg(int a[],int n)
{
    int sum=0;
    for (int i = 0; i < n; i++)
    {
        sum=sum+a[i];
    }
    return (sum/n);
}
void print(struct Patient* list,int num)
{
    printf("ID\tBPaverage\n");
    for (int i=0; i<num; i++) {
        printf("%d\t%d\n",list[i].ID,list[i].BPaverge);
    }
}
