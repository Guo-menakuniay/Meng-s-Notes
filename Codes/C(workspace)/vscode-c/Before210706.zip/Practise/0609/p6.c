#include<stdio.h>
#include<string.h>
int main()
{
    void copy(int a[],int b[]);  //数组复制函数,将a赋给b
    void swap(int x[],int size);  //数组排序
    char staff[10][30];  //职员列表数组
    char newstaff[10][30];
    int a[10]={0},b[10]={0};

    //录入职员信息
    printf("录入职员姓名和职工号，示例：张三 1\n");
    for (int i = 0; i < 10; i++)
    {
        scanf("%s %d",staff[i],(a+i));
    }
    //将a[]中编号与职员信息一一对应
    copy(a,b);

    //对a进行排序
    swap(a,10);
    
    //对排序后职员重新一一对应
     for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            char temp[30];
            if (a[i]==b[j])
            {
                strcpy(temp,staff[j]);
                strcpy(newstaff[i],temp);
            }

        }
    }
    //折半查找法搜索职员
    int mid,high=9,low=0;
    int input;
    printf("输入要查找的职工号\n");
    scanf("%d",&input);
    while (low<=high)
    {
        mid=(low+high)/2;
        if (a[mid]==input)
        {
            printf("该职员%s，职工号为%d\n",newstaff[mid],a[mid]);
            break;
        }
        else if (a[mid]>input)
        {
            high=mid-1;
        }
        else
            low=mid+1;
    }
    
    return 0;
}
void copy(int a[],int b[]) //数组复制
{
    //逐行复制
    for (int i = 0; i < 10; i++)
       {
           *(b+i)=*(a+i);
       }
}

void swap(int x[],int size) //数组排序
{
     for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            int temp=0;
            if ( *(x+j)>*(x+j+1))
            {
                temp=*(x+j);
                *(x+j)=*(x+j+1);
                *(x+j+1)=temp;
            }       
        }   
    }
}
