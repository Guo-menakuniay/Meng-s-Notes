#include<stdio.h>

int main()
{
    int  n,x,y;
    int ack(int n,int x,int y);   //ackermann函数计算部分
    int res;
    printf("依次输入n,x,y\n");
    scanf("%d,%d,%d",&n,&x,&y);
    
    if (n<0 || x<0 ||y<0)
    {
        printf("data error");   //不合规范的数据提醒
    }
    else
    {
    res=ack(n, x, y);
    printf("Solve=%d",res);
    }
    
    return 0;
}

 int ack(int n,int x,int y)  //函数逻辑部分
{
     int k = 0.0;
     if (n!=0 && y!=0)
        {
            k=ack(n-1,ack(n,x,y-1),x);
        }
    if (n==0) {k=x+1; }
    if (n==1 && y==0) {k=x; }
    if (n==2 && y==0) {k=0; }
    if (n==3 && y==0) {k=1; }
    if (n>=4 && y==0) {k=2; }
    
    return k;
}
