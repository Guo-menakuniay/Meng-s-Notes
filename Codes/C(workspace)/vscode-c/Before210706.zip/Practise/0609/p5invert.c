#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
    char a[100]={0};
    int n; //转换的进制
    int finderror(char *a,int n); //错误与否的判断
    float positonapart(char *a,int n);  //位权展开
    float output;
    printf("请输入原有进制和相应数字,以空格隔开\n");
    scanf("%d %s",&n,a); //录入字符串
    if (finderror(a,n)==1)
    {
        output=positonapart(a,n);
        printf("该数的十进制为%.2f\n",output);
    }
    else
        printf("data error\n");

    return 0;
}
float positonapart(char *a,int n)
{
    float output = 0.0;
    unsigned long length=strlen(a);
    //位权展开
    for (int i = 0; i < length; i++)
    {
        int temp=0;
        unsigned long position=length-i-1;
        if (*(a+i)>='A')    //字母转换为相应数字
        {
            temp=a[i]-'A'+10;
            output=output+pow(n,position)*temp;
        }
        else
        {
            temp=a[i]-'0';
            output=output+pow(n,position)*temp;
        }
    }
    
    return output;
}
int finderror(char *a,int n)
{
    char standard[n];
    int output=0;
    for (int i = 0; i < n; i++)  //定义合理的输入
    {
        if (i<10)
        {
            standard[i]='0'+i;
        }
        if (i>10)
        {
            standard[i]='A'+(i-10);
        }
    }
     for (int i = 0; i < strlen(a); i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (*(a+i)==standard[j])
            {
                output=1;
                break;
            }
        }
        if (output==0) {
            break;
        }
    }
    return output;
}
