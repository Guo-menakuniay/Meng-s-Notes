#include<stdio.h>
#include<math.h>
#define Pi 3.1415926
int main()
{
    double func(double x);
    double inte(double a,double b);
    double solve=0;

    solve=inte(0,2*Pi);
    printf("%f",solve);
    return 0;
}

//函数定义
double func(double x)
{
    double f;
    //f=4/(1+x*x);
    f=(1-cos(x))*(1-cos(x));
    return f;
}

//复化抛物线微积分公式
double inte(double a,double b)
{
    double total1(double a,double k,int n); //循环次数i
    double total2(double a,double k,int n);
    double integrate,move1;
    int n=10000;
    long double h=(b-a)/n;

    move1=total1(a,h,n)+total2(a,h,n)+func(a)+func(b);
    integrate=(h*move1)/3;
    

    return integrate;
}
//求和项1
double total1(double a,double k,int n)
{
    double sum=0;
    double x;
    for (int i = 1; i <= (n/2); i++)
    {
        x=a+(2*i-1)*k;
        sum=sum+func(x);
    }
    
    sum=4*sum;

    return sum;
}

//求和项2
double total2(double a,double k,int n)
{
    double sum=0;
    double x;
    for (int i = 2; i <= (n/2); i++)
    {
        x=a+(2*i-2)*k;
        sum=sum+func(x);
    }
    
    sum=2*sum;

    return sum;
}
