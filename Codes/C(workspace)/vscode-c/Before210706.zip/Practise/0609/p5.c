#include <stdio.h>
char a[1000];
int main()
{
    int y = 0, n, x; //x为目的进制
    char z = 'A';
    printf("依次输入要转换的数字和转换的进制:\n");
    scanf("%d %d", &n, &x);
    while (n != 0)
    {    //进制转换部分
        y++;
        a[y] = n % x;
        n = n / x;
        if (a[y] > 9)
            a[y] = z + (a[y] - 10);
        else
            a[y] = a[y] + '0';
    }
    for (int i = y; i > 0; i--)
        printf("%c", a[i]);
    return 0;
}

