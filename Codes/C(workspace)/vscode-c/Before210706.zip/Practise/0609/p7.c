#include<stdio.h>
#include<string.h>
int main()
{
    int scoreQ(char key[],char x[],int size);
    void jude1(char key[],char x[],int size);
    char key[20],answer[100][30];
    int ID[100]={1};
    int number=0;  //记录录入学生的总人数
    
    printf("请输入正确答案：\n");
    //获取正确答案
    gets(key);

    printf("请依次输入学生的ID,回车后输入答案，再次回车输入下位同学，以0结束：\n");
    //读取ID和答案
    for (int i = 0; ; i++)
    {
        scanf("%d",&ID[i]);
        getchar();
        if (ID[i]==0)     //读取0时停止读取
        {
            number=i;
            printf("完成读取，开始输出结果\n");
            break;
        }
        gets(answer[i]);
       
    }
    //输出判断结果
    for (int i = 0; i<= number ; i++)
    {
        if (ID[i]==0)
        {
            continue;
        }
        else
        {
            printf("ID %d: ",ID[i]);
            jude1(key,answer[i],strlen(answer[i]));
        }
    }
    
    return 0;
}

int scoreQ(char key[],char x[],int size)   //分数判断与输出
{
    int score=0;
    for (int i = 0; i < 20; i++)
    {
        if (x[i]==key[i])
        {
            score=score+5;
        }
        
    }
    printf("score is %d\n",score);
    
    return score;
}

void jude1(char key[],char x[],int size)   //无效字符判断  step1
{
    void jude2(char key[],char x[],int size);
    int temp=0;   //0代表不符合规范 1代表符合规范
   for (int i = 0; i < size; i++)
   {
       if (x[i]=='a' || x[i]=='b' || x[i]=='c' || x[i]=='d' || x[i]=='e' || x[i]=='f')
       {
           temp=1;
       }
       else
       {    temp=0; }
   }
    if (temp==1) {
        jude2(key, x, size);
    }
    else
        printf("Invaild input\n");
}

void jude2(char key[],char x[],int size)   //无效长度判断  step2
{
    if (strlen(x)==strlen(key))
    {
        scoreQ(key,x,size);
    }
    if (strlen(x)>strlen(key))
    {
       printf("Too many answers\n");
    }
    if (strlen(x)<strlen(key))
    {
        printf("Too few answers\n");
    }
    
}
