#include<stdio.h>
double squre(double a)
{
    a=a*a;
    return a;
}
int main()
{
    float a[10][5]={{98,98,98,98,98},{10,20,30,40,50},{50,60,70,80,90},{60,60,60,60,60},{23,4,35,90,90},{98,98,98,98,98},{10,20,30,40,50},{50,60,70,80,90},{60,60,60,60,60},{23,4,35,90,90}};
    double squre(double a);
    float avg1(float a[][5],int size,int student); //avge of student
    float avg2(float a[][5],int size,int subject);//avge of subject
    float var(float a[][5],int size,int student);
    int max=0,position[2]={0};
    int *pmax=&max;
    void findmax(float (*a)[5],int size1,int size2,int* pmax,int *position);
    

    float avgofstudent[10]; //学生平均值
    for (int i = 0; i < 10; i++)
    {
        avgofstudent[i]=avg1(a,5,i);
    }
    
    float varofstudent[10]; //学生成绩方差
    for (int i = 0; i < 10; i++)
    {
        varofstudent[i]=var(a,5,i);
    }
    
    float avgofsub[10];  //学科平均值
    for (int i = 0; i < 5; i++)
    {
        avgofsub[i]=avg2(a,5,i);
    }
    
    printf("0到9号学生的平均分分别为：\n"); //1
    for (int i = 0; i < 10; i++)
    {
        printf("%.2f ",avgofstudent[i]);
    }
    printf("\n");
    printf("0到9号学生分数方差别为：\n"); //1
    for (int i = 0; i < 10; i++)
    {
        printf("%.2f ",varofstudent[i]);
    }
    printf("\n");
    printf("0到4号学科的平均分分别为：\n"); //1
    for (int i = 0; i < 5; i++)
    {
        printf("%.2f ",avgofsub[i]);
    }
    printf("\n");
    //最高分查找
    findmax(a,10,5,pmax,position);
    printf("最高分为%d，是%d号学生的%d号学科\n",*pmax,position[0],position[1]);

    return 0;
}

float avg1(float a[][5],int size,int student)  //avge of student
{
    float m = 0.0;
    for (int i = 0; i < 5 ; i++)
    {
        m=m+*(*(a+student)+i);
    }
    m=m/size;

    return m;
}
float avg2(float a[][5],int size,int subject) //avge of subject
{
    float m = 0.0;
    for (int i = 0; i < 5 ; i++)
    {
        m=m+*(*(a+i)+subject);
    }
    m=m/size;

    return m;
}
void findmax(float (*a)[5],int size1,int size2,int* pmax,int *position)  //find max and position
{
     for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            if (*pmax< *(*(a+i)+j) )
        {
            *pmax=*(*(a+i)+j);
            *position=i;
            *(position+1)=j;
        }
        }
    }
}
float var(float a[][5],int size,int student)  //方差计算
{
    float k;
    float sigma1=0,sigma2=0;
    for (int i = 0; i < 5; i++)
    {
        sigma1=sigma1+squre(*(*(a+student)+i));
    }
    for (int i = 0; i < 5; i++)
    {
        sigma2=sigma2+(*(*(a+student)+i));
    }
    
    k=sigma1/size - squre(sigma2/size);

    return k;
}
