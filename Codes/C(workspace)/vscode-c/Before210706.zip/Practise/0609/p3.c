#include <stdio.h>
#include <string.h>
int rankChar(char str[],unsigned long length)
{
    char same[100]={0}; int m=0,count[100]={0};
    int b[200] = {0};
    char k;
    //ASCII排序
    for (int j = 0; j < length; j++)
    {
        for (int i = 0; i <length - 1 - j; i++)
            if (str[i] > str[i + 1])
            {
                k = str[i];
                str[i] = str[i + 1];
                str[i + 1] = k;
            }
    }
    
    for (int i = 0; i < length; i++)
        {
            for (int j = 0; j < length; j++)   //一次扫描重复元素
            {
                if (str[j] == str[i])
                {
                    b[i]++;
                    if (b[i] > 1)              //除自己外若仍存在重复
                    {
                        same[m]=str[j];     //将重复元素和重复次数列入另一个新数组
                        count[m]=b[i]-1;
                        m++;
                        str[j] = 0;
                    }
                }
            }
        }
    //整合重复数字
     for (int i = 0; i < length; i++)
    {
        for (int j = 0; j < length && j!=i; j++)
        {
            if(same[j]==same[i])
            {
                same[j]=0;
                count[i]=(count[i]>count[j])? count[i]:count[j];
                count[j]=0;
            }
        }
    }
    
    //打印结果
    int sum=0;
    for (int i=0; i<=length; i++)
    {
        if (count[i]!=0&&same[i]!='\0')
        {
            sum=sum+count[i];
        }
    }
    printf("删除了%d个字符后，字符排序为：\n",sum);
    for (int i = 0; i < length; i++)
    {
        if (str[i] != 0)
            printf("%c", str[i]);
    }
    return 0;
}

int main()
{
    int rankChar(char str[],unsigned long length);
    unsigned long length;
    char string[100] = {0};
    gets(string);
    length=strlen(string);
    
    rankChar(string,length);
    return 0;
}
