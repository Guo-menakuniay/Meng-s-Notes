#include<stdio.h>

int main()
{
    int a[16][16];
    
    //每列的初值1的定义
    for (int i = 0; i <=14; i++)
    {
        a[i][0]=1;
        a[i][i]=1;
    }
    //杨辉三角定义
    for (int i = 2; i <= 14; i++)
    {
        for (int j = 1; j <=i-1; j++)
        {
            a[i][j]=a[i-1][j-1]+a[i-1][j];
        }
        
    }

    //打印结果
    for (int i = 0; i <= 14; i++)
    {
        for (int j = 0; j <= i; j++)
        {
            printf("%d ",a[i][j]);
        }
        printf("\n");
    }
    
    return 0;
}
