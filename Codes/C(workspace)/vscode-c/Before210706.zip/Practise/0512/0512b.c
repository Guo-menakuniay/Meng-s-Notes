#include<stdio.h>
int main()
{
    char string[256]="A new documentary about Michael Jordan’s career has become the latest bige-worthy Netflix show. It highlights the story of Jordan’s last year with the Chicago Bulls. The ten episodes feature hours of never-before-seen video of him and his teammates.";
    //题目
    /* In the midst of many US states reopening, the US passed 100,000 coronavirus deaths. 
       In the same week, California passed 100,000 coronavirus cases. Experts say that without better testing and tracing, those numbers will continue to rise.
       A new documentary about Michael Jordan’s career has become the latest bige-worthy Netflix show. It highlights the story of Jordan’s last year with the Chicago Bulls. The ten episodes feature hours of never-before-seen video of him and his teammates.

    */
    int num=0,word=0,letter=0,Letter=0,others=0,space=0;
    char c;

    puts(string);

    for (int i = 0; (c=string[i])!='\0';i++)
    {
        if (c==' ')
        {  word=0;}
        else if (word==0)
        {
            word=1;
            num++;
        }
        //大写字母
        if ((string[i]>='A')&&(string[i]<='Z'))
        {
            Letter++;
        }
        //小写字母
        if ((string[i]>='a') && (string[i]<='z'))
        {
            letter++;
        }
        //空格数
        if (string[i]==' ')
        {
            space++;
        }
        //其他字符数
        if ( (!(string[i]>='A')&&(string[i]<='Z')) && (!(string[i]>='a') && (string[i]<='z')) &&string[i]!=' ')
        {
            others++;
        }
        
    }
    
    printf("单词、英文大写字母、小写字母、空格以及其他字符的个数分别为%d,%d,%d,%d,%d",num,Letter,letter,space,others);
    

    return 0;
}
