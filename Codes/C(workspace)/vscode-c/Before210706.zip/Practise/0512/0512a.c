#include<stdio.h>
#include<string.h>
int main()
{
    int a[]={-3,4,-1,-11,7,3,-5,9,-22,2,10,-7};
    //b-the opptive; c-the negative
    int b[10],c[10];
    int m=0,n=0;
    int z[12];   //输出结果

    for (int i = 0 ; i <=12;i++)
    {
        if (a[i]>=0)
        {
            b[m]=a[i];
            m++;
        }
        else
        {
            c[n]=a[i];
            n++;
        }
    }
    
    for (int i = 0; i <=5; i++)
    {
        z[i]=c[i];
    }
    
    for (int i = 6; i <=11;i++)
    {
        z[i]=b[i-6];
    }
    for(int i=0;i<=11;i++)
    {
        printf("%d ",z[i]);
    }

    return 0;
}
