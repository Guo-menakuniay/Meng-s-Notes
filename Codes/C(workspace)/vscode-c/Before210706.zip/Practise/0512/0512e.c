#include<stdio.h>
int main()
{
    int array[5][5]={{99,69,16,36,60},{18,41,39,69,34},{26,99,17,30,30},{40,41,76,54,46},{8,63,88,84,43}};
    int linemax=0;
    int line = 0,colum = 0;
    int judge[5][5]={0};
    int point=0;
    //鞍点判断
    for (int i = 0; i <=4; i++)       //逐行扫描
    {
        for (int j = 0; j <=4; j++)
        {
            if(array[i][j]>linemax)     //当行最大值
            {
                linemax=array[i][j];
                line=i;
                colum=j;
            }
            if (j==4)
            {
                judge[line][colum]=1;
                for (int k = 0; k <=4; k++)
                {
                    if (array[k][colum]<array[line][colum])  //保留逻辑值和对应的坐标
                    {
                        judge[line][colum]=0;
                    }
                    linemax=0;     //临时值归零
                }
            }
        }
    }
    
    //结果输出
    for (int i = 0; i <=4; i++)
    {
        for (int j = 0; j <=4; j++)    //对judge数组挑选出满足题意的值
        {
            if (judge[i][j]!=0)
            {
                printf("有鞍点值为%d,位于（%d,%d)\n",array[i][j],i,j);
                point++;
            }
        }
    }
    
    //无鞍点情况
    if (point==0)
    {
        printf("不存在鞍点\n");
    }
    
    return 0;
}

