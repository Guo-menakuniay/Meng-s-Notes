#include<stdio.h>

int main()
{
    int a[5][5]={{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15},{16,17,18,19,20},{21,22,23,24,25}};
    int b[5][3]={{3,0,16},{17,-6,9},{0,23,-4},{9,7,0},{4,13,11}};
    int c[5][3];
    int sum=0;
    //令得c矩阵初值为0
    for (int i=0; i<=4; i++)
    {
        for (int j=0; j<=2; j++)
        {
            c[i][j]=0;
        }
    }
    //矩阵乘法
    for (int i = 0; i <=4; i++)
    {
        for (int j = 0; j <=2; j++)
        {
            for (int k = 0; k <=4; k++)
            {
                sum=a[i][k]*b[k][j];
                c[i][j]=c[i][j]+sum;
            }
            
        }
        
    }
    //打印运算结果
    for (int i=0; i<=4; i++)
        {
            for (int j=0; j<=2; j++)
            {
               printf("%d ",c[i][j]);
            }
            printf("\n");
        }
    
    return 0;
}
