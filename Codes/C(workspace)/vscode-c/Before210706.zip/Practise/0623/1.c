#include<stdio.h>
struct staff
{
    char name[30];
    int number;
};
int main()
{
    struct staff sta[10];
    struct staff temp;
    printf("输入职员的姓名和职工号\n");
    for (int i = 0; i < 10; i++)
    {
        scanf("%s %d",&sta[i].name,&sta[i].number);
    }
    //排序
    for (int j; j < 9; j++)
    {
        for (int i = 0; i < 9; i++)
        {
            if (sta[i].number>sta[i+1].number)
                {
                    temp=sta[i];
                    sta[i]=sta[i+1];
                    sta[i+1]=temp;
                }
        }
    }
        
    printf("排序之后的结果是：\n");
    //打印
    
    for (int i = 0; i < 10; i++)
    {
        printf("%s %d\n",sta[i].name,sta[i].number);
    }
     //折半查找法搜索职员
    int mid,high=9,low=0;
    int input;
    printf("输入要查找的职工号\n");
    scanf("%d",&input);
    while (low<=high)
    {
        mid=(low+high)/2;
        if (sta[mid].number==input)
        {
            printf("该职员%s，职工号为%d\n",sta[mid].name,sta[mid].number);
            break;
        }
        else if (sta[mid].number>input)
        {
            high=mid-1;
        }
        else
            low=mid+1;
    }
    
    
    return 0;
}
