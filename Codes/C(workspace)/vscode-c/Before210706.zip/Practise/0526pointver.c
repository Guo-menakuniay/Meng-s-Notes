#include<stdio.h>
int b[12]={31,28,31,30,31,30,31,31,30,31,30,31};

void fun(int *a,const int week0)
{
    int *day;
    int *year0;
    int leapyear(int year);   //leap=0 不是闰年，leap=1 是闰年
    if (leapyear(*year0)==1)
    {
        b[1]=b[1]+1;
    }
    //星期判断
    for (int i = 0; i <=11; i++)
    {
        day=day+b[i-1];
        a[i]=*day%7+week0;
        if (a[i]>=7)
        {
            a[i]=a[i]-7;  //a[i]代表i+1月的首月星期
        }
    }
}


int leapyear(int year)     //闰年判断函数
{
    int leap;

    if(year%4==0)
      {
          if(year%100!=0)
            leap=1;
          else leap=0;
          if (year%400==0)
          {
              leap=1;
          }
            
      }
    else leap=0;
    
    return leap;
}

int main()
{
    void fun(int *a,const int week0);
    int target=0,year,week; //获取目标月份
    int* p=&year;
    int month[12]={0}; //每月首日的星期 数组
    
    //数据获取部分
    printf("请输入年份和当年第一天的星期数（用0代表周日，1代表周一，以此类推），示例：2020 3\n");
    scanf("%d %d",&year,&week);
    printf("请输入你想查看的月份日历(输入当月数字即可）\n");
    scanf("%d",&target);
    
    fun(p, week);
    
    //标题打印
    printf("The Calender of %d %d\n",target,year);
    printf("Sat\tMon\tTue\tWed\tThu\tFri\tSat\n");

    int m=1;//每日计数变量的定义
    printf(" ");
    //日历输出部分
     for (int j = 1; j <=(month[target-1]+b[target-1]); j++)
    {
        if (j<month[target-1]+1)
            {
                printf("  \t ");  //稳定输出位置 简化排版
            }
        else
            {
                printf("%d\t ",m++);
            }
        
        if (j%7==0)   //每周换行
        {
            printf("\n ");
        }
        
    }
}
