#include <stdio.h>
#include <string.h>
int main()
{
    char string[100] = {0};
    char same[100]={0}; int m=0,count[100]={0};
    int b[200] = {0};
    char k;

    gets(string);
    int length = strlen(string);
    //ASCII排序
    for (int j = 0; j < strlen(string); j++)
    {
        for (int i = 0; i < strlen(string) - 1 - j; i++)
            if (string[i] > string[i + 1])
            {
                k = string[i];
                string[i] = string[i + 1];
                string[i + 1] = k;
            }
    }
    //输出仅排序
    printf("原数组按ASCII从小到大排序为：\n");
    printf("%s\n", string);

    for (int i = 0; i < length; i++)
    {
        for (int j = 0; j < length; j++)   //一次扫描重复元素
        {
            if (string[j] == string[i])
            {
                b[i]++;
                if (b[i] > 1)              //除自己外若仍存在重复
                {
                    same[m]=string[j];     //将重复元素和重复次数列入另一个新数组
                    count[m]=b[i]-1;
                    m++;
                    string[j] = 0;
                }
            }
        }
    }
    
    //整合重复数字
     for (int i = 0; i < length; i++)
    {
        for (int j = 0; j < length&&j!=i; j++)
        {
            if(same[j]==same[i])
            {
                same[j]=0;
                count[i]=(count[i]>count[j])? count[i]:count[j];
                count[j]=0;
            }
        }
    }
    
    //分别打印去重后的结果和重复元素结果
    printf("处理之后的序列排序如下：\n");
    for (int i = 0; i < length; i++)
    {
        if (string[i] != 0)
            printf("%c", string[i]);
    }
    printf("\n重复的情况如下：\n");
    for (int i=0; i<=length; i++)
    {
        if (count[i]!=0&&same[i]!='\0')
        {
            printf("%c重复了%d次 ",same[i],count[i]);
        }
    }
    return 0;
}
