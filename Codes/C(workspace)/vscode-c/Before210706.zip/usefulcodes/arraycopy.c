#include<stdio.h>
#include<time.h>
#include<stdlib.h>
int main()
{
    void copy(int a[][10],int b[][10]);
    srand((unsigned) time(NULL));
    int a[10][10];
    int b[10][10]={0};  //复制目标数组
    
    for (int i = 0; i < 10; i++)
    {
        for(int j=0; j < 10;j++)
        {
            a[i][j]=rand()%100+1;
        }
    }
    copy(a,b);
    return 0;
}

void copy(int a[][10],int b[][10])
{
    //逐行复制
    for (int i = 0; i < 10; i++)
       {
           for (int j = 0; j<10; j++)
           {
               *(*(b+i)+j)=*(*(a+i)+j);
           }
       }
}
