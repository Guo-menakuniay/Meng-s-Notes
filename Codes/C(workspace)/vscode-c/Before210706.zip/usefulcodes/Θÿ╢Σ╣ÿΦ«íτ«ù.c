#include<stdio.h>
float fac(float n)
{
    float f;
    if (n<0)
    {
        printf("error\n");
    }
    else if (n==0 || n==1)       
    {
        f=1;
    }
    else
        f=fac(n-1)*n;

    return f;
}

int main()
{
    float n;
    float y;
    printf("Please enter a integer number\n");
    scanf("%f",&n);
    printf("%f! = %f",n,fac(n));

    return 0;
}