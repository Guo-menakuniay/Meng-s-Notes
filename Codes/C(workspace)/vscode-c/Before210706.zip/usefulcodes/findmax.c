#include<stdio.h>
#include<time.h>
#include<stdlib.h>
int main()
{
    void findmax(int *a,int size,int *pmax,int *ppos);
    srand((unsigned) time(NULL));
    int a[10],max=0,pos=0;
    int* pmax=&max;
    int* ppos=&pos;
    for (int i = 0; i < 10; i++)
    {
        a[i]=rand()%100+1;
    }
    findmax(a,10,pmax,ppos);
    printf("the max value is %d , in position %d",*pmax,*ppos); 


    return 0;
}
void findmax(int *a,int size,int* pmax,int *ppos)
{
    for (int i = 0; i < size; i++)
    {
        if (*pmax<*a)
        {
            *pmax=*a;
            *ppos=*ppos+1;
        }
        a++;
    }
}